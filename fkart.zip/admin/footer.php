<?php
// This is footer.php. It contains the footer and closing tags for all pages.
?>
</html>
